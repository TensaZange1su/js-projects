document.addEventListener('DOMContentLoaded', () => {
    const messageDiv = document.getElementById('messages');
    const messageInput = document.getElementById('messageInput');
    const chatForm = document.getElementById('chatForm');


    const channel = new BroadcastChannel('chat_channel');

    
    function displayMessage(message) {
        const newMessage = document.createElement('p');
        newMessage.textContent = message;
        newMessage.classList.add('message');
        messageDiv.appendChild(newMessage);
        messageDiv.scrollTop = messageDiv.scrollHeight; 
    }


    chatForm.addEventListener('submit', (e) => {
        e.preventDefault();
        const message = messageInput.value;

        if (message) {
    
            channel.postMessage(message);
        
            displayMessage(`You: ${message}`);
            
            messageInput.value = '';
        }
    });

    channel.onmessage = (event) => {
        displayMessage(`Other: ${event.data}`);
    };
});
