const express = require('express');
const app = express();

app.use(express.json());

//post route to handle '/submit'
app.post('/submit', (req, res) => {
  console.log(req.body);  // log received to console
  res.send('Data received successfully.');  //reponse back
});

//add a GET route
app.get('/', (req, res) => {
  res.send('Welcome to the homepage!'); //response when accessing route
});

//start
const PORT = 3000;
app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});
