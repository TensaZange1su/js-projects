const blogForm = document.getElementById('blogForm');
const blogList = document.getElementById('blogList');


async function fetchBlogs() {
    const response = await fetch('/api/blogs');
    const blogs = await response.json();
    displayBlogs(blogs);
}


function displayBlogs(blogs) {
    blogList.innerHTML = '';
    blogs.forEach(blog => {
        const blogDiv = document.createElement('div');
        blogDiv.className = 'blog';
        blogDiv.innerHTML = `
            <h3>${blog.title}</h3>
            <p>${blog.body}</p>
            <p><em>Author: ${blog.author}</em></p>
            <button onclick="deleteBlog('${blog._id}')">Delete</button>
            <button onclick="updateBlog('${blog._id}')">Update</button>
        `;
        blogList.appendChild(blogDiv);
    });
}


blogForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const title = document.getElementById('title').value;
    const body = document.getElementById('body').value;
    const author = document.getElementById('author').value;

    const response = await fetch('/api/blogs', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ title, body, author })
    });

    if (response.ok) {
        fetchBlogs(); 
        blogForm.reset(); 
    }
});

async function deleteBlog(id) {
    const response = await fetch(`/api/blogs/${id}`, {
        method: 'DELETE'
    });
    if (response.ok) {
        fetchBlogs(); 
    }
}


async function updateBlog(id) {
    const title = prompt("Enter new title:");
    const body = prompt("Enter new body:");

    const response = await fetch(`/api/blogs/${id}`, {
        method: 'PUT',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ title, body })
    });

    if (response.ok) {
        fetchBlogs(); 
    }
}

fetchBlogs();
