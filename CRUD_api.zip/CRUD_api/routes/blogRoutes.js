
const express = require('express');
const Blog = require('../models/Blog');
const router = express.Router();


router.post('/blogs', async (req, res) => {
  try {
    const { title, body, author } = req.body;

    
    if (!title || !body) {
      return res.status(400).json({ message: 'title and body' });
    }

    const blog = new Blog({ title, body, author });
    await blog.save();
    res.status(201).json(blog);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

router.get('/blogs', async (req, res) => {
  try {
    const blogs = await Blog.find();
    res.json(blogs);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

router.get('/blogs/:id', async (req, res) => {
  try {
    const blog = await Blog.findById(req.params.id);
    if (!blog) return res.status(404).json({ message: 'no blog' });
    res.json(blog);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

router.put('/blogs/:id', async (req, res) => {
  try {
    const { title, body } = req.body;

    if (!title || !body) {
      return res.status(400).json({ message: 'title and bod' });
    }

    const updatedBlog = await Blog.findByIdAndUpdate(req.params.id, { title, body }, { new: true });
    if (!updatedBlog) return res.status(404).json({ message: 'no blog' });
    res.json(updatedBlog);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

router.delete('/blogs/:id', async (req, res) => {
  try {
    const deletedBlog = await Blog.findByIdAndDelete(req.params.id);
    if (!deletedBlog) return res.status(404).json({ message: 'no blog' });
    res.json({ message: 'blog deleted' });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

module.exports = router;
