const express = require('express');
const path = require('path');
const app = express();
const PORT = 3000;

let messages = []; // Хранение сообщений

// Middleware для обработки данных формы
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

// Сервируем статические файлы из папки 'mychat'
app.use('/static', express.static(path.join(__dirname, 'mychat')));

// Маршрут для '/'
app.get('/', (req, res) => {
    res.send('hi');
});

// Маршрут для '/json'
app.get('/json', (req, res) => {
    res.json({
        text: 'hi',
        numbers: [1, 2, 3]
    });
});

// Маршрут для '/echo'
app.get('/echo', (req, res) => {
    const message = req.query.message || '';
    const response = {
        normal: message,
        shouty: message.toUpperCase(),
        count: message.length,
        backwards: message.split('').reverse().join('')
    };
    res.json(response);
});

// Маршрут для '/chat' - отправка сообщений
app.post('/chat', (req, res) => {
    const message = req.body.message;
    if (message) {
        messages.push(message);
        res.status(200).json({ status: 'Message received' });
    } else {
        res.status(400).json({ error: 'No message provided' });
    }
});

// SSE-соединение для реального времени
app.get('/sse', (req, res) => {
    res.setHeader('Content-Type', 'text/event-stream');
    res.setHeader('Cache-Control', 'no-cache');
    res.setHeader('Connection', 'keep-alive');

    const sendMessages = () => {
        if (messages.length > 0) {
            messages.forEach(msg => res.write(`data: ${msg}\n\n`));
            messages = []; // Очистка сообщений после отправки
        }
    };

    const interval = setInterval(sendMessages, 1000);

    req.on('close', () => {
        clearInterval(interval);
        res.end();
    });
});

// Запуск сервера на порту 3000
app.listen(PORT, () => {
    console.log(`Server is listening on port ${PORT}`);
});
