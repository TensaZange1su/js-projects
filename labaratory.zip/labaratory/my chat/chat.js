document.addEventListener('DOMContentLoaded', () => {
    const messageDiv = document.getElementById('messages');
    const messageInput = document.getElementById('messageInput');
    const chatForm = document.getElementById('chatForm');

    // Создаем канал для общения между вкладками
    const channel = new BroadcastChannel('chat_channel');

    // Функция для отображения сообщений в текущей вкладке
    function displayMessage(message) {
        const newMessage = document.createElement('p');
        newMessage.textContent = message;
        newMessage.classList.add('message');
        messageDiv.appendChild(newMessage);
        messageDiv.scrollTop = messageDiv.scrollHeight;  // Прокрутка вниз
    }

    // Отправка сообщений через канал
    chatForm.addEventListener('submit', (e) => {
        e.preventDefault();
        const message = messageInput.value;

        if (message) {
            channel.postMessage(message);  // Отправка сообщения через канал
            displayMessage(`You: ${message}`);  // Отображение в текущей вкладке
            messageInput.value = '';  // Очистка поля ввода
        }
    });

    // Получение сообщений из других вкладок через канал
    channel.onmessage = (event) => {
        displayMessage(`Other: ${event.data}`);
    };
});
