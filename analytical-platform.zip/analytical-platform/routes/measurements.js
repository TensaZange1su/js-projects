// backend/routes/measurements.js
const express = require('express');
const Measurement = require('../models/Measurement');
const router = express.Router();

// Get time-series data with filtering
router.get('/', async (req, res) => {
    const { field, start_date, end_date } = req.query;
    if (!field || !['field1', 'field2', 'field3'].includes(field)) {
        return res.status(400).json({ error: 'Invalid field specified.' });
    }

    const filter = {
        timestamp: {
            $gte: new Date(start_date),
            $lte: new Date(end_date)
        }
    };

    try {
        const data = await Measurement.find(filter).select(`timestamp ${field}`);
        res.json(data);
    } catch (error) {
        res.status(500).json({ error: 'Error fetching data' });
    }
});

// Get metrics for a specific field
router.get('/metrics', async (req, res) => {
    const { field } = req.query;
    if (!field || !['field1', 'field2', 'field3'].includes(field)) {
        return res.status(400).json({ error: 'Invalid field specified.' });
    }

    try {
        const data = await Measurement.aggregate([
            { $group: {
                _id: null,
                avg: { $avg: `$${field}` },
                min: { $min: `$${field}` },
                max: { $max: `$${field}` },
                stdDev: { $stdDevPop: `$${field}` }
            }}
        ]);

        res.json(data[0]);
    } catch (error) {
        res.status(500).json({ error: 'Error calculating metrics' });
    }
});

module.exports = router;
