
const mongoose = require('mongoose');
const fs = require('fs');
const Measurement = require('./models/Measurement'); 


mongoose.connect('mongodb://localhost:27017/analyticalPlatform', {
    useNewUrlParser: true,
    useUnifiedTopology: true
})
.then(() => console.log('MongoDB connected'))
.catch(error => console.log('MongoDB connection error:', error));


const data = JSON.parse(fs.readFileSync('dataset.json', 'utf8'));


async function importData() {
    try {
        await Measurement.deleteMany(); 
        await Measurement.insertMany(data); 
        console.log('Data successfully imported');
        process.exit();
    } catch (error) {
        console.error('Error importing data:', error);
        process.exit(1);
    }
}


importData();
