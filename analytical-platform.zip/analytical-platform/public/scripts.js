async function fetchData() {
    const field = document.getElementById('field').value;
    const startDate = document.getElementById('start-date').value;
    const endDate = document.getElementById('end-date').value;

    const response = await fetch(`http://localhost:3000/api/measurements?field=${field}&start_date=${startDate}&end_date=${endDate}`);
    const data = await response.json();

    const timestamps = data.map(entry => new Date(entry.timestamp).toLocaleDateString());
    const values = data.map(entry => entry[field]);

    renderChart(timestamps, values, field);
}

function renderChart(labels, data, label) {
    const ctx = document.getElementById('data-chart').getContext('2d');
    new Chart(ctx, {
        type: 'line',
        data: {
            labels: labels,
            datasets: [{
                label: label,
                data: data,
                borderColor: 'rgba(75, 192, 192, 1)',
                borderWidth: 2,
                fill: false,
            }]
        },
        options: {
            scales: {
                x: { title: { display: true, text: 'Date' } },
                y: { title: { display: true, text: label } }
            }
        }
    });
}
