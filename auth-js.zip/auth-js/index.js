const http = require("http");
const express = require("express");
const app = express();
const bcrypt = require('bcrypt');

app.use(express.static(__dirname + '/public'));
app.use(express.static(__dirname + '/auth'));

app.get("/", (req, res) => {
    res.sendFile(__dirname + "/public/index.html");
});


const urlencodedParser = express.urlencoded({extended: false});
const log = require("./auth/login");

app.post("/login", urlencodedParser , (req, res) => {
    log.login(req, res);
} );


app.post("/sign_up", urlencodedParser, (req, res) => {
    log.sign_up(req, res)    
});


const PORT = 8080; 
const HOST = 'localhost'
app.listen(PORT, () => {console.log(`Hello Server: http://localhost:${PORT}`)});


