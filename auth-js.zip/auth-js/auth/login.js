const bcrypt = require("bcrypt");

async function login(req, res){
    const db = require("../db" );

    let errors = 0;
    let error_text = "";
    let login = req.body.login;
    let password = req.body.password

    if(login < 2 || password < 4){
        error_text += "Too short name or password";
        errors += 1;
    }

    const results = await db.query(`SELECT * FROM users WHERE login = $1`, [login]);
    console.log(results);
    if (results.rows.length > 0) {
        console.log("User already exist");
        error_text += "| 2 User already exist"
        errors += 1;
    } 

    res.send(error_text);

    let hash_pass = bcrypt.hashSync(password, 7);
    if(errors == 0){
        const new_person = db.query(`INSERT INTO users(login, password) VALUES($1, $2) RETURNING *`,[login, hash_pass])
    }
}

async function sign_up(req, res){
    const db = require("../db" );

    let errors = 0;
    let login = req.body.login;
    let password = req.body.password
    const results = await db.query(`SELECT * FROM users WHERE login = $1`, [login]);

    if (results.rows.length == 0) {
        res.send('User doesnot exist');
        errors += 1;
    } else{
        console.log(results.rows[0]['password']);
        let password_from_db = results.rows[0]['password'];

        bcrypt.compare(password, password_from_db, (err, result) => {
            if (err) {
                console.error('Error comparing passwords:', err);
            }
        
            if (result) {
                res.send('Passwords match! User authenticated.');
            } else {
                res.send('Passwords do not match! Authentication failed.');
            }
        });
    }
    

}




module.exports = {login, sign_up};





