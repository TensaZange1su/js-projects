bda2304 

1. install all npm extensions
2. start npm server
3. check db



Almas Kuratov, Dulat Tulebayev, Aiken Altay