const token = localStorage.getItem('token');

// Проверка токена
if (!token) {
  alert('Пожалуйста, войдите в систему.');
  window.location.href = '/'; // Перенаправление на страницу входа
}

// Обработчик добавления задачи
document.getElementById('todoForm').addEventListener('submit', async (event) => {
  event.preventDefault(); 

  const text = document.getElementById('todoText').value;

  try {
    const response = await fetch('/todos', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`,
      },
      body: JSON.stringify({ text }),
    });

    const todo = await response.json();
    if (response.ok) {
      addTodoToList(todo);
      document.getElementById('todoText').value = ''; // Очистить поле ввода
    } else {
      alert(`Ошибка: ${todo.message}`);
    }
  } catch (err) {
    alert(`Ошибка: ${err.message}`);
  }
});

// Загрузка задач при открытии страницы
async function loadTodos() {
  try {
    const response = await fetch('/todos', {
      headers: { 'Authorization': `Bearer ${token}` },
    });

    const todos = await response.json();
    todos.forEach(addTodoToList);
  } catch (err) {
    console.error('Error loading tasks:', err);
  }
}

// Функция добавления задачи в список на странице
function addTodoToList(todo) {
  const li = document.createElement('li');
  li.textContent = todo.text;

  const deleteButton = document.createElement('button');
  deleteButton.textContent = 'Delete';
  deleteButton.addEventListener('click', () => deleteTodo(todo._id, li));

  li.appendChild(deleteButton);
  document.getElementById('todoList').appendChild(li);
}

// Удаление задачи
async function deleteTodo(id, element) {
  try {
    const response = await fetch(`/todos/${id}`, {
      method: 'DELETE',
      headers: { 'Authorization': `Bearer ${token}` },
    });

    if (response.ok) {
      element.remove();
    } else {
      alert('Error when deleting task');
    }
  } catch (err) {
    console.error('Error:', err);
  }
}

// Обработчик выхода из системы
document.getElementById('logoutButton').addEventListener('click', () => {
  localStorage.removeItem('token'); // Удаляем токен
  window.location.href = '/'; // Перенаправляем на страницу входа
});

// Загружаем задачи при загрузке страницы
loadTodos();
