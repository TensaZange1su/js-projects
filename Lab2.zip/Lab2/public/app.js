// для регистрации
document.getElementById('registerForm').addEventListener('submit', async (event) => {
    event.preventDefault();
  
    const name = document.getElementById('name').value;
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;
  
    try {
      const response = await fetch('/auth/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, email, password }),
      });
  
      const data = await response.json();
      if (response.ok) {
        alert('Registered successfully!');
      } else {
        alert(`Error: ${data.message}`);
      }
    } catch (err) {
      alert(`Error: ${err.message}`);
    }
  });
  
  // Логика для входа
  document.getElementById('loginForm').addEventListener('submit', async (event) => {
    event.preventDefault(); // Отключаем перезагрузку страницы
  
    const email = document.getElementById('loginEmail').value;
    const password = document.getElementById('loginPassword').value;
  
    try {
      const response = await fetch('/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password }),
      });
  
      const data = await response.json();
      if (response.ok) {
        localStorage.setItem('token', data.token); // Сохраняем токен
        alert('Login successful!');
        window.location.href = '/todo.html'; // Переход на To-Do страницу
      } else {
        alert(`Error: ${data.message}`);
      }
    } catch (err) {
      alert(`Error: ${err.message}`);
    }
  });
  