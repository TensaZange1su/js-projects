module.exports = {
    openWeatherApiKey: '048a5181ab1157983b754d91128ad461',
    newsApiKey: 'IUKlJ0vGsdqMhN6xht9YpB8r6ibCPA5Wm8aO2Lf5',
    currencyExchangeApiKey: 'ec61b0d025d577a34fba868f'
  };
  